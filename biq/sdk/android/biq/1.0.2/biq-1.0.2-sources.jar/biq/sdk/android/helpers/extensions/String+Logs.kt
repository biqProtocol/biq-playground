package biq.sdk.android.helpers.extensions

import android.util.Log
import biq.sdk.android.BuildConfig

internal fun String.logErrorMessage(tag: String = "") {
    if (BuildConfig.DEBUG) {
        Log.e(tag, this)
    }
}

internal fun String.logDebugMessage(tag: String = "") {
    if (BuildConfig.DEBUG) {
        Log.d(tag, this)
    }
}