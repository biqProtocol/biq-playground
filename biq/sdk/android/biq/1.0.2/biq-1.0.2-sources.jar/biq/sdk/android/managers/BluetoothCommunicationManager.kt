package biq.sdk.android.managers

import android.Manifest.permission.BLUETOOTH_CONNECT
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context.BLUETOOTH_SERVICE
import android.util.Log
import androidx.annotation.RequiresPermission
import biq.sdk.android.BuildConfig
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.providers.ContextProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.altbeacon.beacon.Beacon
import java.time.LocalDateTime
import java.util.UUID

internal object BluetoothCommunicationManager {

    private const val TAG = "BluetoothCommunicationManager"

    // TODO: remove hardcoded UUIDS
    val SERVICE_UUID: UUID = UUID.fromString("0000abcd-0000-1000-8000-00805f9b34fb")
    val NONCE_WRITE_CHAR_UUID: UUID = UUID.fromString("0000beef-0000-1000-8000-00805f9b34fb")
    val SIGNATURE_NOTIFY_CHAR_UUID: UUID = UUID.fromString("0000feed-0000-1000-8000-00805f9b34fb")

    @RequiresPermission(BLUETOOTH_CONNECT)
    fun handleDetectedBeacon(beacon: Beacon, id: String) {
        val lastUsage = SharedPrefsManager.getBeaconDate(id)
        val isReadyToLog =
            lastUsage == null || lastUsage.isBefore(LocalDateTime.now().minusMinutes(2))

        "Not ready to BLE connection, need to wait longer.".logDebugMessage()
        if (!isReadyToLog) return

        SharedPrefsManager.saveBeaconDate(id)

        CoroutineScope(Dispatchers.IO).launch {
            val nonce = getNonce()

            logBondedDevices()

            val macAddress = beacon.bluetoothAddress
            // TODO replace deprecation
            val device = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(macAddress)

            connectToBeaconAndSendNonce(device, nonce)
        }
    }

    @RequiresPermission(BLUETOOTH_CONNECT)
    private fun connectToBeaconAndSendNonce(device: BluetoothDevice, nonce: String) {
        device.connectGatt(ContextProvider.get(), false, object : BluetoothGattCallback() {
            @RequiresPermission(BLUETOOTH_CONNECT)
            override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    "Connected to GATT".logDebugMessage(TAG)
                    gatt.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    "Disconnected from GATT".logDebugMessage(TAG)
                    gatt.close()
                }
            }

            @RequiresPermission(BLUETOOTH_CONNECT)
            override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                for (service in gatt.services) {
                    "Discovered service: ${service.uuid}".logDebugMessage(TAG)
                }

                val service = gatt.getService(SERVICE_UUID)
                val nonceChar = service?.getCharacteristic(NONCE_WRITE_CHAR_UUID)
                val signatureChar = service?.getCharacteristic(SIGNATURE_NOTIFY_CHAR_UUID)

                if (nonceChar != null && signatureChar != null) {
                    gatt.setCharacteristicNotification(signatureChar, true)

                    // Write a descriptor to enable notifications on some devices:
                    // TODO: Replace hardcoded UUID and deprecated calls
                    val descriptor = signatureChar.getDescriptor(
                        UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
                    )
                    descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    gatt.writeDescriptor(descriptor)

                    // Write nonce
                    nonceChar.value = nonce.toByteArray()
                    val success = gatt.writeCharacteristic(nonceChar)
                    Log.d(
                        TAG,
                        "Wrote nonce: $nonce, success = $success"
                    )
                } else {
                    Log.w(TAG, "Missing required characteristics")

                    // TODO: Replace with server call for receiving the signature and send it to server
                    CoroutineScope(Dispatchers.IO).launch {
                        val success = sendSignature()
                        withContext(Dispatchers.Main) {
                            if (success) {
                                "Signature verified successfully by simulated server".logDebugMessage(
                                    TAG
                                )
                            } else {
                                "Simulated server rejected signature".logDebugMessage(
                                    TAG
                                )
                            }

                            gatt.disconnect() // disconnect after server call
                        }
                    }
                }
            }

            // TODO replace deprecation
            @Deprecated("Deprecated in Java")
            @RequiresPermission(BLUETOOTH_CONNECT)
            override fun onCharacteristicChanged(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic
            ) {
                if (characteristic.uuid == SIGNATURE_NOTIFY_CHAR_UUID) {
                    val signature = characteristic.value
                    "Received signature from beacon: ${signature.decodeToString()}".logDebugMessage(
                        TAG
                    )
                    gatt.disconnect()
                }
            }
        })
    }

    // TODO
    suspend fun getNonce(): String {
        "Request nonce.".logDebugMessage(TAG)
        delay(500)
        return "nonce-${System.currentTimeMillis()}"
    }

    // TODO
    suspend fun sendSignature(): Boolean {
        "Signature sent.".logDebugMessage(TAG)
        delay(600)
        return true
    }

    @RequiresPermission(BLUETOOTH_CONNECT)
    private fun logBondedDevices() {
        if (!BuildConfig.DEBUG) {
            return
        }

        val bluetoothManager =
            ContextProvider.get().getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        val bluetoothAdapter = bluetoothManager.adapter

        // TODO remove if used only for logs
        bluetoothAdapter.bondedDevices.forEach { device ->
            "Device: ${device.name} - ${device.address}".logDebugMessage(TAG)
            device.uuids?.forEach { uuid ->
                "UUID: ${uuid.uuid}".logDebugMessage(TAG)
            }
        }
    }
}