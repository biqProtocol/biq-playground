package biq.sdk.android.networking.interceptors

import biq.sdk.android.managers.SharedPrefsManager
import okhttp3.Interceptor
import okhttp3.Response

internal class SessionAuthInterceptor : Interceptor {

    companion object {
        const val AUTHORIZATION: String = "Authorization"
        const val BEARER = "Bearer"
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val authToken = SharedPrefsManager.getAccessToken()

        val request = chain
            .request()
            .newBuilder()

        if (authToken != null) {
            when (authToken.isEmpty()) {
                false -> request.addHeader(AUTHORIZATION, "$BEARER $authToken")
                else -> {}
            }
        }

        return chain.proceed(
            request.build()
        )
    }
}