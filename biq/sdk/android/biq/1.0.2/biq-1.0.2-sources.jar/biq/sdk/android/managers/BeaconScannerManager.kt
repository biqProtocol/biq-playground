package biq.sdk.android.managers

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.Observer
import biq.sdk.android.helpers.ConnectionState
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.providers.ContextProvider
import com.davidgyoungtech.beaconparsers.IBeaconParser
import org.altbeacon.beacon.Beacon
import org.altbeacon.beacon.BeaconManager
import org.altbeacon.beacon.BeaconRegion
import org.altbeacon.beacon.MonitorNotifier
import org.altbeacon.beacon.Settings

internal class BeaconScannerManager() {

    companion object {
        const val TAG = "BeaconScannerManager"
    }

    private var beaconManager: BeaconManager? = null

    // TODO get from server
    private val ids = listOf(
        "a6c35242-8310-4a6f-b60a-e8edad5498cd"
    )

    // TODO handle id1 to match requirements
    private val iBeaconRegion = BeaconRegion(
        "everyIBeaconRegion",
        IBeaconParser(),
        "a6c35242-8310-4a6f-b60a-e8edad5498cd",
        null,
        null
    )

    private val centralMonitoringObserver = Observer<Int> { state ->
        if (state == MonitorNotifier.OUTSIDE) {
            "Outside beacon region.".logDebugMessage(TAG)
            beaconManager?.stopRangingBeacons(iBeaconRegion)
        } else {
            "Inside beacon region.".logDebugMessage(TAG)
            beaconManager?.startRangingBeacons(iBeaconRegion)

            // Stop ranging after 10 seconds to save battery
            // TODO: see if this is required
            Handler(Looper.getMainLooper()).postDelayed({
                "Inside beacon region for 10 seconds - stopping ranging.".logDebugMessage(TAG)
                beaconManager?.stopRangingBeacons(iBeaconRegion)
            }, 10_000)

            // TODO: notify integrator that we are in range
            NotificationsManager.sendNearbyNotification()
        }
    }

    @SuppressLint("MissingPermission")
    private val centralRangingObserver = Observer<Collection<Beacon>> { beacons ->
        val rangeAgeMillis =
            System.currentTimeMillis() - (beacons.firstOrNull()?.lastCycleDetectionTimestamp ?: 0)

        if (rangeAgeMillis < 10000) {
            "Ranged: ${beacons.count()} beacons".logDebugMessage(TAG)

            for (beacon: Beacon in beacons) {
                "$beacon about ${beacon.distance} meters away".logDebugMessage(TAG)
                val beaconId = beacon.id1.toUuid().toString()
                if (ids.contains(beaconId)) {
                    BluetoothCommunicationManager.handleDetectedBeacon(beacon, beaconId)
                }
            }
        } else {
            "Ignoring stale ranged beacons from $rangeAgeMillis millis ago".logDebugMessage(TAG)
        }
    }

    fun startRangingBeacons() {
        val beaconManager = BeaconManager.getInstanceForApplication(ContextProvider.get())
        if (beaconManager.rangedRegions.isEmpty()) {
            beaconManager.startRangingBeacons(iBeaconRegion)
        }
    }

    fun stopRangingBeacons() {
        val beaconManager = BeaconManager.getInstanceForApplication(ContextProvider.get())
        if (beaconManager.rangedRegions.isNotEmpty()) {
            beaconManager.stopRangingBeacons(iBeaconRegion)
        }
    }

    fun startMonitoringBeacon() {
        val beaconManager = BeaconManager.getInstanceForApplication(ContextProvider.get())
        if (beaconManager.monitoredRegions.isEmpty()) {
            beaconManager.startMonitoring(iBeaconRegion)
        }
    }

    fun stopMonitoringBeacon() {
        val beaconManager = BeaconManager.getInstanceForApplication(ContextProvider.get())
        if (beaconManager.monitoredRegions.isNotEmpty()) {
            beaconManager.stopMonitoring(iBeaconRegion)
        }
    }

    fun startScanning(
        onPermissionError: (ConnectionState.MissingPermission) -> Unit
    ) {
        val isPermission = PermissionsManager.allPermissionsGranted {
            onPermissionError(it)
        }
        if (!isPermission) return

        val beaconManager = BeaconManager.getInstanceForApplication(ContextProvider.get())
        if (beaconManager.monitoredRegions.isEmpty()) {
            setupBeaconScanning()
        }
    }

    private fun setupBeaconScanning() {
        val beaconManager = BeaconManager.getInstanceForApplication(ContextProvider.get())

        val settings = getForegroundServiceScanningSettings()
        beaconManager.replaceSettings(settings)
//        beaconManager.adjustSettings(Settings(debug = true))

        beaconManager.startMonitoring(iBeaconRegion)
        beaconManager.startRangingBeacons(iBeaconRegion)

        val regionViewModel =
            BeaconManager.getInstanceForApplication(ContextProvider.get())
                .getRegionViewModel(iBeaconRegion)
        // observer will be called each time the monitored regionState changes (inside vs. outside region)
        regionViewModel.regionState.observeForever(centralMonitoringObserver)
        // observer will be called each time a new list of beacons is ranged (typically ~1 second in the foreground)
        regionViewModel.rangedBeacons.observeForever(centralRangingObserver)

        this.beaconManager = beaconManager
    }

    private fun getForegroundServiceScanningSettings() = Settings(
        scanStrategy = Settings.ForegroundServiceScanStrategy(
            NotificationsManager.getScanningForegroundNotification(),
            456
        ),
        scanPeriods = Settings.ScanPeriods(
            1100,
            0,
            1100,
            0
        ),
        longScanForcingEnabled = true
    )
}