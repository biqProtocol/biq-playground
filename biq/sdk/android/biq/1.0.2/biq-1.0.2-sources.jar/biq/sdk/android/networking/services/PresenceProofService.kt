package biq.sdk.android.networking.services

interface PresenceProofService {
    // TODO provide PresenceProofService methods
}