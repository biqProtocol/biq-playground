package biq.sdk.android.networking.services

interface AuthenticationService {
    // TODO provide AuthenticationService methods
}