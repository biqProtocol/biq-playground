package biq.sdk.android.managers

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import biq.sdk.android.providers.ContextProvider
import java.time.LocalDateTime

internal object SharedPrefsManager {

    private const val SESSION_FILE_NAME = "biq-sdk-prefs"
    private const val ACCESS_TOKEN_KEY = "accessToken"

    private val sharedPreferences: SharedPreferences? by lazy {
        ContextProvider.get().getSharedPreferences(
            SESSION_FILE_NAME, Context.MODE_PRIVATE
        )
    }

    fun saveBeaconDate(beaconId: String) = writeString(beaconId, LocalDateTime.now().toString())
    fun getBeaconDate(beaconId: String) = readString(beaconId)?.let {
        LocalDateTime.parse(it)
    }

    fun saveAccessToken(accessToken: String) = writeString(ACCESS_TOKEN_KEY, accessToken)
    fun getAccessToken() = readString(ACCESS_TOKEN_KEY)
    fun removeAccessToken() = remove(ACCESS_TOKEN_KEY)

    private fun writeString(key: String, value: String) = sharedPreferences?.edit {
        putString(key, value)
    }

    private fun readString(key: String) = sharedPreferences?.getString(key, null)

    private fun remove(key: String) = sharedPreferences?.edit {
        remove(key)
    }
}