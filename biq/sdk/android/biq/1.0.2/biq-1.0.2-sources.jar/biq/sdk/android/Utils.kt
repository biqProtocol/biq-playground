package biq.sdk.android

import android.util.Log

object Utils {
    fun printHello() {
        Log.d(Utils::class.simpleName, "Hello World!")
    }
}