package biq.sdk.android.networking.repositories

import biq.sdk.android.networking.RetrofitInstance
import biq.sdk.android.networking.services.PresenceProofService

object PresenceProofServiceRepository {

    private val retService: PresenceProofService by lazy {
        RetrofitInstance
            .authInstance
            .create(PresenceProofService::class.java)
    }

    // TODO provide PresenceProofService methods
}