package biq.sdk.android

import android.app.Activity
import android.content.Context
import biq.sdk.android.helpers.ConnectionState
import biq.sdk.android.managers.BeaconScannerManager
import biq.sdk.android.managers.NotificationsManager
import biq.sdk.android.providers.ContextProvider

class BiqController private constructor() {

    private val beaconScannerManager = BeaconScannerManager()

    companion object {
        const val TAG = "BiqController"

        @Volatile
        private var INSTANCE: BiqController? = null

        fun getInstance(): BiqController {
            return INSTANCE
                ?: throw IllegalStateException("BiqController is not initialized.")
        }
    }

    class Builder(private val context: Context) {
        fun setNotificationEntryPoint(targetActivity: Class<out Activity>) = apply {
            NotificationsManager.configure(targetActivity)
        }

        fun build(): BiqController {
            synchronized(this) {
                if (INSTANCE == null) {
                    ContextProvider.init(context)

                    INSTANCE = BiqController()
                }
                return INSTANCE!!
            }
        }
    }

    fun scan(onPermissionError: (ConnectionState.MissingPermission) -> Unit) {
        beaconScannerManager.startScanning(onPermissionError)
    }
}