package biq.sdk.android.managers

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import biq.sdk.android.helpers.ConnectionState
import biq.sdk.android.providers.ContextProvider

internal object PermissionsManager {

    // Manifest.permission.ACCESS_BACKGROUND_LOCATION
    // Manifest.permission.ACCESS_FINE_LOCATION
    // Manifest.permission.BLUETOOTH_CONNECT
    // Manifest.permission.BLUETOOTH_SCAN

    fun allPermissionsGranted(
        onPermissionNotGranted: (permission: ConnectionState.MissingPermission) -> Unit
    ): Boolean {
        val permissionsGroups = getRequiredPermissions()

        for (permissionsGroup in permissionsGroups) {
            for (permission in permissionsGroup) {
                if (!isPermissionGranted(permission)) {
                    onPermissionNotGranted(ConnectionState.MissingPermission(permission))
                    return false
                }
            }
        }

        return true
    }

    private fun isPermissionGranted(permissionString: String): Boolean {
        return (ContextCompat.checkSelfPermission(
            ContextProvider.get(),
            permissionString
        ) == PackageManager.PERMISSION_GRANTED)
    }

    fun getRequiredPermissions(): List<Array<String>> {
        val permissions = ArrayList<Array<String>>()
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            // As of version M (6) we need FINE_LOCATION (or COARSE_LOCATION, but we ask for FINE)
//            permissions.add(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION))
//        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // As of version Q (10) we need FINE_LOCATION and BACKGROUND_LOCATION
            permissions.add(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // As of version S (12) we need FINE_LOCATION, BLUETOOTH_SCAN and BACKGROUND_LOCATION
            // Manifest.permission.BLUETOOTH_CONNECT is not absolutely required to do just scanning,
            // but it is required if you want to access some info from the scans like the device name
            // and the additional cost of requesting this access is minimal, so we just request it
            permissions.add(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_ADVERTISE
                )
            )
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // As of version nonBeaconBeaconRegionT (13) we POST_NOTIFICATIONS permissions if using a foreground service
            permissions.add(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        }
        return permissions
    }

}