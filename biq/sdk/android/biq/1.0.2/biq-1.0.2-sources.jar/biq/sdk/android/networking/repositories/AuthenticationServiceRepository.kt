package biq.sdk.android.networking.repositories

import androidx.lifecycle.LiveData
import biq.sdk.android.networking.RetrofitInstance
import biq.sdk.android.networking.services.AuthenticationService
import kotlinx.coroutines.Dispatchers
import retrofit2.Response

object AuthenticationServiceRepository {

    private val retService: AuthenticationService by lazy {
        RetrofitInstance
            .instance
            .create(AuthenticationService::class.java)
    }

    // TODO provide AuthenticationService methods
}